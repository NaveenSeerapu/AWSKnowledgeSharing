import json
from database.adtdataaccesslayer import ADTDataAccessLayer

adtdataaccesslayer = ADTDataAccessLayer();

class AppService:

    def get(self):
        return self.tasksJSON

    def create_event(self, event):
        return adtdataaccesslayer.create("ADTEvent", event);

    def update_event(self, event):
        return adtdataaccesslayer.create("ADTEvent", event);

    def delete(self, request_task_id):
        pass

    
