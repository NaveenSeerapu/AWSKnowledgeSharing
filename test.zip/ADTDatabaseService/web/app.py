from flask import Flask, request
from services.app_service import AppService 
import json

app = Flask(__name__)
appService = AppService();


@app.route('/')
def home():
    return "App Works!!!"


@app.route('/api/adtcentraldata/<int:id>')
def read():
    pass

@app.route('/api/adtcentraldata/', methods=['POST'])
def create():
    request_data = request.get_json()
    event = request_data['event']
    return appService.create_event(event)


@app.route('/api/adtcentraldata', methods=['PATCH'])
def update():
    request_data = request.get_json()
    event = request_data['event']
    return appService.update_event(event)

    
@app.route('/api/adtcentraldata', methods=['DELETE'])
def delete():
    request_data = request.get_json()
    event = request_data['event']
    pass
