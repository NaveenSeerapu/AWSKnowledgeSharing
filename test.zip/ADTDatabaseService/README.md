# python-flask-restapi
The service is an API that hanndles data for ADT Central Events
