from _typeshed import Self
import pyodbc

# define the server and the database
server = 'adtcentraldbserver.database.windows.net' 
database = 'CentralEventsDB'  
user = 'microsoft@adtcentraldbserver'
password ='Computervision1.'

# Define the connection strin

class ADTDataAccessLayer:
    
    def __init__(self):
        # Create the Cursor.
        self.dbconnection = pyodbc.connect('DRIVER={SQL Server}; SERVER='+ server +'; DATABASE='+ database +'; UID='+ user +'; PWD = '+ password +'; Trusted_Connection=yes;Integrated Security=False;')
        self.cursor = self.dbconnection.cursor()

    def create(entityName, parameters):
        try:
            spName = 'pub_Create' + entityName
            sqlstmt = r'exec ' + spName + '  @ADTEvent = ' + "'" + str(parameters) + "'"
            Self.cursor.execute(sqlstmt)
            Self.dbconnection.commit()
            return True
        except:
            return False

    def update(entityName, parameters):
        try:
            spName = 'pub_Update' + entityName
            sqlstmt = r'exec ' + spName + '  @ADTEvent = ' + "'" + str(parameters) + "'"
            Self.cursor.execute(sqlstmt)
            Self.dbconnection.commit()
            return True
        except:
            return False

    def read(entityName, parameters):
        try:
            spName = 'pub_Get' + entityName
            sqlstmt = r'exec ' + spName + '  @ADTEvent = ' + "'" + str(parameters) + "'"
            Self.cursor.execute(sqlstmt)
            Self.dbconnection.commit()
            return True
        except:
            return False

    def delete(entityName, parameters):
        try:
            spName = 'pub_Delete' + entityName
            sqlstmt = r'exec ' + spName + '  @ADTEvent = ' + "'" + str(parameters) + "'"
            Self.cursor.execute(sqlstmt)
            Self.dbconnection.commit()
            return True
        except:
            return False

    def __del__(self):
  # body of destructor
        Self.cursor.close()
        Self.dbconnection.close()
